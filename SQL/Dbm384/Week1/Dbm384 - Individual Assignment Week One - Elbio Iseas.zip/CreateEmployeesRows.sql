﻿
INSERT INTO [dbo].[Employees] 

( [ID], [FirstName], [LastName],  [SalaryId] )

VALUES 

( 1, 'Adam',   'Schmitt',   4),
( 2, 'Elbio',  'Iseas',     3),
( 3, 'Neil',   'Goldstein', 2),
( 4, 'Sharon', 'Foster',    1),
( 5, 'Jane',   'Doe',       5),
( 6, 'John',   'Doe',       6);
