﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustSummary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCustSL = New System.Windows.Forms.Label()
        Me.lblCoCS = New System.Windows.Forms.Label()
        Me.txtCompanySL = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblCustSL
        '
        Me.lblCustSL.AutoSize = True
        Me.lblCustSL.Font = New System.Drawing.Font("Impact", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustSL.Location = New System.Drawing.Point(175, 30)
        Me.lblCustSL.Name = "lblCustSL"
        Me.lblCustSL.Size = New System.Drawing.Size(245, 29)
        Me.lblCustSL.TabIndex = 1
        Me.lblCustSL.Text = "Customer Summary List"
        '
        'lblCoCS
        '
        Me.lblCoCS.AutoSize = True
        Me.lblCoCS.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCoCS.Location = New System.Drawing.Point(30, 99)
        Me.lblCoCS.Name = "lblCoCS"
        Me.lblCoCS.Size = New System.Drawing.Size(83, 18)
        Me.lblCoCS.TabIndex = 2
        Me.lblCoCS.Text = "Company"
        '
        'txtCompanySL
        '
        Me.txtCompanySL.Location = New System.Drawing.Point(130, 100)
        Me.txtCompanySL.Name = "txtCompanySL"
        Me.txtCompanySL.Size = New System.Drawing.Size(437, 20)
        Me.txtCompanySL.TabIndex = 3
        '
        'frmCustSummary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(612, 431)
        Me.Controls.Add(Me.txtCompanySL)
        Me.Controls.Add(Me.lblCoCS)
        Me.Controls.Add(Me.lblCustSL)
        Me.Name = "frmCustSummary"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer Summary Listing"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblCustSL As System.Windows.Forms.Label
    Friend WithEvents lblCoCS As System.Windows.Forms.Label
    Friend WithEvents txtCompanySL As System.Windows.Forms.TextBox
End Class
