﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustTrans
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCustTransCT = New System.Windows.Forms.Label()
        Me.lblCoCT = New System.Windows.Forms.Label()
        Me.lblTransCT = New System.Windows.Forms.Label()
        Me.lblTransTypeCT = New System.Windows.Forms.Label()
        Me.lblRepCT = New System.Windows.Forms.Label()
        Me.lblDateCT = New System.Windows.Forms.Label()
        Me.lblTransDetCT = New System.Windows.Forms.Label()
        Me.txtCompanyCT = New System.Windows.Forms.TextBox()
        Me.txtTransactionCT = New System.Windows.Forms.TextBox()
        Me.txtTransTypeCT = New System.Windows.Forms.TextBox()
        Me.txtRepresentativeCT = New System.Windows.Forms.TextBox()
        Me.txtDateCT = New System.Windows.Forms.TextBox()
        Me.txtTransDetailsCT = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblCustTransCT
        '
        Me.lblCustTransCT.AutoSize = True
        Me.lblCustTransCT.Font = New System.Drawing.Font("Impact", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustTransCT.Location = New System.Drawing.Point(180, 23)
        Me.lblCustTransCT.Name = "lblCustTransCT"
        Me.lblCustTransCT.Size = New System.Drawing.Size(242, 29)
        Me.lblCustTransCT.TabIndex = 1
        Me.lblCustTransCT.Text = "Customer Transactions"
        '
        'lblCoCT
        '
        Me.lblCoCT.AutoSize = True
        Me.lblCoCT.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCoCT.Location = New System.Drawing.Point(33, 99)
        Me.lblCoCT.Name = "lblCoCT"
        Me.lblCoCT.Size = New System.Drawing.Size(83, 18)
        Me.lblCoCT.TabIndex = 2
        Me.lblCoCT.Text = "Company"
        '
        'lblTransCT
        '
        Me.lblTransCT.AutoSize = True
        Me.lblTransCT.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTransCT.Location = New System.Drawing.Point(33, 138)
        Me.lblTransCT.Name = "lblTransCT"
        Me.lblTransCT.Size = New System.Drawing.Size(117, 18)
        Me.lblTransCT.TabIndex = 3
        Me.lblTransCT.Text = "Transaction #"
        '
        'lblTransTypeCT
        '
        Me.lblTransTypeCT.AutoSize = True
        Me.lblTransTypeCT.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTransTypeCT.Location = New System.Drawing.Point(320, 138)
        Me.lblTransTypeCT.Name = "lblTransTypeCT"
        Me.lblTransTypeCT.Size = New System.Drawing.Size(147, 18)
        Me.lblTransTypeCT.TabIndex = 4
        Me.lblTransTypeCT.Text = "Transaction Type"
        '
        'lblRepCT
        '
        Me.lblRepCT.AutoSize = True
        Me.lblRepCT.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRepCT.Location = New System.Drawing.Point(33, 176)
        Me.lblRepCT.Name = "lblRepCT"
        Me.lblRepCT.Size = New System.Drawing.Size(131, 18)
        Me.lblRepCT.TabIndex = 5
        Me.lblRepCT.Text = "Representative"
        '
        'lblDateCT
        '
        Me.lblDateCT.AutoSize = True
        Me.lblDateCT.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateCT.Location = New System.Drawing.Point(33, 215)
        Me.lblDateCT.Name = "lblDateCT"
        Me.lblDateCT.Size = New System.Drawing.Size(146, 18)
        Me.lblDateCT.TabIndex = 6
        Me.lblDateCT.Text = "Transaction Date"
        '
        'lblTransDetCT
        '
        Me.lblTransDetCT.AutoSize = True
        Me.lblTransDetCT.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTransDetCT.Location = New System.Drawing.Point(33, 250)
        Me.lblTransDetCT.Name = "lblTransDetCT"
        Me.lblTransDetCT.Size = New System.Drawing.Size(172, 18)
        Me.lblTransDetCT.TabIndex = 7
        Me.lblTransDetCT.Text = "Transactions Details"
        '
        'txtCompanyCT
        '
        Me.txtCompanyCT.Location = New System.Drawing.Point(130, 98)
        Me.txtCompanyCT.Name = "txtCompanyCT"
        Me.txtCompanyCT.Size = New System.Drawing.Size(443, 20)
        Me.txtCompanyCT.TabIndex = 8
        '
        'txtTransactionCT
        '
        Me.txtTransactionCT.Location = New System.Drawing.Point(161, 137)
        Me.txtTransactionCT.Name = "txtTransactionCT"
        Me.txtTransactionCT.Size = New System.Drawing.Size(153, 20)
        Me.txtTransactionCT.TabIndex = 9
        '
        'txtTransTypeCT
        '
        Me.txtTransTypeCT.Location = New System.Drawing.Point(473, 136)
        Me.txtTransTypeCT.Name = "txtTransTypeCT"
        Me.txtTransTypeCT.Size = New System.Drawing.Size(100, 20)
        Me.txtTransTypeCT.TabIndex = 10
        '
        'txtRepresentativeCT
        '
        Me.txtRepresentativeCT.Location = New System.Drawing.Point(169, 175)
        Me.txtRepresentativeCT.Name = "txtRepresentativeCT"
        Me.txtRepresentativeCT.Size = New System.Drawing.Size(404, 20)
        Me.txtRepresentativeCT.TabIndex = 11
        '
        'txtDateCT
        '
        Me.txtDateCT.Location = New System.Drawing.Point(185, 213)
        Me.txtDateCT.Name = "txtDateCT"
        Me.txtDateCT.Size = New System.Drawing.Size(97, 20)
        Me.txtDateCT.TabIndex = 12
        '
        'txtTransDetailsCT
        '
        Me.txtTransDetailsCT.Location = New System.Drawing.Point(211, 251)
        Me.txtTransDetailsCT.Name = "txtTransDetailsCT"
        Me.txtTransDetailsCT.Size = New System.Drawing.Size(360, 20)
        Me.txtTransDetailsCT.TabIndex = 13
        '
        'frmCustTrans
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(609, 305)
        Me.Controls.Add(Me.txtTransDetailsCT)
        Me.Controls.Add(Me.txtDateCT)
        Me.Controls.Add(Me.txtRepresentativeCT)
        Me.Controls.Add(Me.txtTransTypeCT)
        Me.Controls.Add(Me.txtTransactionCT)
        Me.Controls.Add(Me.txtCompanyCT)
        Me.Controls.Add(Me.lblTransDetCT)
        Me.Controls.Add(Me.lblDateCT)
        Me.Controls.Add(Me.lblRepCT)
        Me.Controls.Add(Me.lblTransTypeCT)
        Me.Controls.Add(Me.lblTransCT)
        Me.Controls.Add(Me.lblCoCT)
        Me.Controls.Add(Me.lblCustTransCT)
        Me.Name = "frmCustTrans"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer Transactions Entry"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblCustTransCT As System.Windows.Forms.Label
    Friend WithEvents lblCoCT As System.Windows.Forms.Label
    Friend WithEvents lblTransCT As System.Windows.Forms.Label
    Friend WithEvents lblTransTypeCT As System.Windows.Forms.Label
    Friend WithEvents lblRepCT As System.Windows.Forms.Label
    Friend WithEvents lblDateCT As System.Windows.Forms.Label
    Friend WithEvents lblTransDetCT As System.Windows.Forms.Label
    Friend WithEvents txtCompanyCT As System.Windows.Forms.TextBox
    Friend WithEvents txtTransactionCT As System.Windows.Forms.TextBox
    Friend WithEvents txtTransTypeCT As System.Windows.Forms.TextBox
    Friend WithEvents txtRepresentativeCT As System.Windows.Forms.TextBox
    Friend WithEvents txtDateCT As System.Windows.Forms.TextBox
    Friend WithEvents txtTransDetailsCT As System.Windows.Forms.TextBox
End Class
