﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustInf
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCustInf = New System.Windows.Forms.Label()
        Me.lblCo = New System.Windows.Forms.Label()
        Me.lblConLN = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblCSZ = New System.Windows.Forms.Label()
        Me.lblPho = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtCompany = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.txtZipCode = New System.Windows.Forms.TextBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.txtFax = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblCustInf
        '
        Me.lblCustInf.AutoSize = True
        Me.lblCustInf.Font = New System.Drawing.Font("Impact", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustInf.Location = New System.Drawing.Point(152, 19)
        Me.lblCustInf.Name = "lblCustInf"
        Me.lblCustInf.Size = New System.Drawing.Size(284, 29)
        Me.lblCustInf.TabIndex = 1
        Me.lblCustInf.Text = "Customer Information Form"
        '
        'lblCo
        '
        Me.lblCo.AutoSize = True
        Me.lblCo.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCo.Location = New System.Drawing.Point(20, 76)
        Me.lblCo.Name = "lblCo"
        Me.lblCo.Size = New System.Drawing.Size(83, 19)
        Me.lblCo.TabIndex = 2
        Me.lblCo.Text = "Company"
        '
        'lblConLN
        '
        Me.lblConLN.AutoSize = True
        Me.lblConLN.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConLN.Location = New System.Drawing.Point(20, 112)
        Me.lblConLN.Name = "lblConLN"
        Me.lblConLN.Size = New System.Drawing.Size(154, 19)
        Me.lblConLN.TabIndex = 3
        Me.lblConLN.Text = "Contact Last Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(20, 147)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(155, 19)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Contact First Name"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddress.Location = New System.Drawing.Point(20, 182)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(73, 19)
        Me.lblAddress.TabIndex = 5
        Me.lblAddress.Text = "Address"
        '
        'lblCSZ
        '
        Me.lblCSZ.AutoSize = True
        Me.lblCSZ.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCSZ.Location = New System.Drawing.Point(19, 216)
        Me.lblCSZ.Name = "lblCSZ"
        Me.lblCSZ.Size = New System.Drawing.Size(116, 19)
        Me.lblCSZ.TabIndex = 6
        Me.lblCSZ.Text = "City, State, Zip"
        '
        'lblPho
        '
        Me.lblPho.AutoSize = True
        Me.lblPho.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPho.Location = New System.Drawing.Point(20, 251)
        Me.lblPho.Name = "lblPho"
        Me.lblPho.Size = New System.Drawing.Size(95, 19)
        Me.lblPho.TabIndex = 7
        Me.lblPho.Text = "Phone, Fax"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(19, 282)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(56, 19)
        Me.lblEmail.TabIndex = 8
        Me.lblEmail.Text = "E-mail"
        '
        'txtCompany
        '
        Me.txtCompany.Location = New System.Drawing.Point(106, 75)
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.Size = New System.Drawing.Size(443, 20)
        Me.txtCompany.TabIndex = 9
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(180, 111)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(369, 20)
        Me.txtLastName.TabIndex = 10
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(181, 147)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(368, 20)
        Me.txtFirstName.TabIndex = 11
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(100, 179)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(449, 20)
        Me.txtAddress.TabIndex = 12
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(140, 215)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(238, 20)
        Me.txtCity.TabIndex = 13
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(401, 215)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(35, 20)
        Me.txtState.TabIndex = 14
        '
        'txtZipCode
        '
        Me.txtZipCode.Location = New System.Drawing.Point(455, 215)
        Me.txtZipCode.Name = "txtZipCode"
        Me.txtZipCode.Size = New System.Drawing.Size(94, 20)
        Me.txtZipCode.TabIndex = 15
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(140, 250)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(172, 20)
        Me.txtPhone.TabIndex = 16
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(330, 250)
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(172, 20)
        Me.txtFax.TabIndex = 17
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(98, 285)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(313, 20)
        Me.txtEmail.TabIndex = 18
        '
        'frmCustInf
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(576, 328)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtFax)
        Me.Controls.Add(Me.txtPhone)
        Me.Controls.Add(Me.txtZipCode)
        Me.Controls.Add(Me.txtState)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtCompany)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.lblPho)
        Me.Controls.Add(Me.lblCSZ)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblConLN)
        Me.Controls.Add(Me.lblCo)
        Me.Controls.Add(Me.lblCustInf)
        Me.Name = "frmCustInf"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer Information Data Entry"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblCustInf As System.Windows.Forms.Label
    Friend WithEvents lblCo As System.Windows.Forms.Label
    Friend WithEvents lblConLN As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblCSZ As System.Windows.Forms.Label
    Friend WithEvents lblPho As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents txtCompany As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents txtState As System.Windows.Forms.TextBox
    Friend WithEvents txtZipCode As System.Windows.Forms.TextBox
    Friend WithEvents txtPhone As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
End Class
