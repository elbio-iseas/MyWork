﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMenuScreen = New System.Windows.Forms.Label()
        Me.btnCustInf = New System.Windows.Forms.Button()
        Me.btnTrans = New System.Windows.Forms.Button()
        Me.btnSummary = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblMenuScreen
        '
        Me.lblMenuScreen.AutoSize = True
        Me.lblMenuScreen.Font = New System.Drawing.Font("Impact", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuScreen.Location = New System.Drawing.Point(112, 30)
        Me.lblMenuScreen.Name = "lblMenuScreen"
        Me.lblMenuScreen.Size = New System.Drawing.Size(315, 29)
        Me.lblMenuScreen.TabIndex = 0
        Me.lblMenuScreen.Text = "Customer Relation Information"
        '
        'btnCustInf
        '
        Me.btnCustInf.BackColor = System.Drawing.Color.DarkBlue
        Me.btnCustInf.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCustInf.ForeColor = System.Drawing.Color.Gold
        Me.btnCustInf.Location = New System.Drawing.Point(170, 108)
        Me.btnCustInf.Name = "btnCustInf"
        Me.btnCustInf.Size = New System.Drawing.Size(199, 28)
        Me.btnCustInf.TabIndex = 1
        Me.btnCustInf.Text = "Customer Information"
        Me.btnCustInf.UseVisualStyleBackColor = False
        '
        'btnTrans
        '
        Me.btnTrans.BackColor = System.Drawing.Color.DarkBlue
        Me.btnTrans.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTrans.ForeColor = System.Drawing.Color.Gold
        Me.btnTrans.Location = New System.Drawing.Point(170, 176)
        Me.btnTrans.Name = "btnTrans"
        Me.btnTrans.Size = New System.Drawing.Size(199, 28)
        Me.btnTrans.TabIndex = 2
        Me.btnTrans.Text = "Transactions"
        Me.btnTrans.UseVisualStyleBackColor = False
        '
        'btnSummary
        '
        Me.btnSummary.BackColor = System.Drawing.Color.DarkBlue
        Me.btnSummary.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSummary.ForeColor = System.Drawing.Color.Gold
        Me.btnSummary.Location = New System.Drawing.Point(170, 237)
        Me.btnSummary.Name = "btnSummary"
        Me.btnSummary.Size = New System.Drawing.Size(199, 28)
        Me.btnSummary.TabIndex = 3
        Me.btnSummary.Text = "Summary"
        Me.btnSummary.UseVisualStyleBackColor = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(530, 322)
        Me.Controls.Add(Me.btnSummary)
        Me.Controls.Add(Me.btnTrans)
        Me.Controls.Add(Me.btnCustInf)
        Me.Controls.Add(Me.lblMenuScreen)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "POS408 Learning Team A"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblMenuScreen As System.Windows.Forms.Label
    Friend WithEvents btnCustInf As System.Windows.Forms.Button
    Friend WithEvents btnTrans As System.Windows.Forms.Button
    Friend WithEvents btnSummary As System.Windows.Forms.Button

End Class
