﻿Public Class frmMain

    Private Sub btnCustInf_Click(sender As System.Object, e As System.EventArgs) Handles btnCustInf.Click
        frmCustInf.Show()
    End Sub

    Private Sub btnTrans_Click(sender As System.Object, e As System.EventArgs) Handles btnTrans.Click
        frmCustTrans.Show()
    End Sub

    Private Sub btnSummary_Click(sender As System.Object, e As System.EventArgs) Handles btnSummary.Click
        frmCustSummary.Show()
    End Sub
End Class
