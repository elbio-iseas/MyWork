# include <iostream>
# include <iomanip>
using namespace std;

//Prototype.
void showTotalSales(double, int);

int main()
{
	const char TAKEN = 'T';		//Taken seats.
	const char EMPTY = 'A';		//Available seats.
	const int row = 11;			//Values held in rows.
	const int column = 11;		//Values held in columns.
	int i;						//Index of rows.
	int j;					    //Index of columns.
	int k;						//Counter for displaying columns.
	int tickets_sold = 0;		//Number of tickets sold.
	char map[row][column];		//2D array to hold seating chart.
	char selection;				//Menus choices.
	double price = 5.00;	    //Ticket price is $5.00 each.

	//Format pricing.
	cout << fixed << showpoint << setprecision(2);

	//Display a map of the theater.
	cout << "Seats  ";
	for (k = 1; k < column; k++)//Display numbers 1 to 10 representing the columns.
		cout << setw(3) << "" << k;//Spaces out column numbers.

	for (i = 1; i < row; i++) //Display row #.
	{
		cout << endl << "Row " << setw(3) << i;//Spaces out row #.
			for (j = 1; j < column; j++)
			{
				map[i][j] = EMPTY;//Initializes the 2D-array.
				cout << setw(3) << "" << EMPTY;//Displays available seating.
			}
	}

	do
	{
		//Display the menu.
		cout << "\n\nMAIN MENU" << endl;
		cout << "---------" << endl;
		cout << "Press (1) to Sell a Ticket ($5.00)" << endl;
		cout << "Press (2) to Quit" << endl;
		cout << "Press (3) to See Total Sales" << endl;
		cout << endl;
		cout << "Please make a selection: ";
		cin >> selection;
			
		if (selection == '1')
		{
			cout << "Please enter a row and seat number.\n" ;
			cout << "Row # :" ;
			cin >> i;
			cout << "Seat # :" ;
			cin >> j;
			cout << endl;

			//Check if seat is taken.
			if(map[i][j] == TAKEN)
			{
				cout << "Seat Taken!. \n";
				continue; //Loop again.
			}
			else //Sell seat.
			{
				map[i][j] = TAKEN;
				tickets_sold++;
				cout << tickets_sold << " seat(s) have been sold." << endl;
				cout << (100 - tickets_sold) << " seat(s) remain available." << endl;
				cin.ignore();
				cout << "Press ENTER to continue.";
				cin.get();
				cout << endl;
			}

			//Add the next loop to see effects.
			cout << "Seats  " ;
			for (k = 1; k < column; k++) //Loop to display nums up top 1 - 10.
				cout << setw(3) << "" << k;
			for(i = 1; i < row; i++)//Making array display what's in it.
			{
				cout << endl << "Row " << setw(3) << i;
				for (j = 1; j < column; j++)
					cout << setw(3) << "" << map[i][j];
			}
		}

		//Quit the program.
		else if (selection == '2')
			return 0;

		//Show total sales.
		else if (selection == '3')
		{
			showTotalSales(price, tickets_sold);
			cin.ignore();
			cout << "Press ENTER to continue.";
			cin.get();
		}

		//Ask for correct input.
		else 	
			cout << "Please enter a valid selection.\n";

	}while (selection > '1' || selection < '3');	
}

//Function for total sales.
void showTotalSales(double price, int tickets)
{
	cout << "Total Sales = $" << (price * tickets) << endl;
}
