﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Links
{
    class BinaryTree
    {
        Node root;
        Node current;
        Node latest;

        public BinaryTree()
        {
            root = null;
            current = null;
            latest = null;
        }

        public void addNode(Data data) 
        {

        }
    }
}
