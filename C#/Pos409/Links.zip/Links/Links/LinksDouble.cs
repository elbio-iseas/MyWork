﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Links
{
    class LinksDouble
    {

        LinkD first;
        LinkD current;
        LinkD latest;
        LinkD last;

        public LinksDouble()
        {
            first = null;
            current = null;
            latest = null;
            last = null;
        }

        public void addAfterCurrent(Data data)
        {

            latest = new LinkD(null, new Data(data), null);
            if (first == null)                          // Adding first link
            {
                first = latest;
            }
            else
            {
                if (current.getTail() != null)          // if adding in middle
                {                 
                    latest.setTail(current.getTail());    //point tail and next link
                    latest.getTail().setHead(latest);       // point next head back to new link
                }
                else
                {
                    last = latest;
                }
                // whether in the middle or the end
                latest.setHead(current);
                current.setTail(latest);
            }

            current = latest;                         // last now becomes current
        }

        public void addBeforeCurrent(Data data)
        {
            //TODO: this is currently AfterCurrent.  Need to switch to BeforeCurrent

            latest = new LinkD(null, new Data(data), null);
            if (first == null)                          // Adding first link
            {
                first = latest;
            }
            else
            {
                if (current.getHead() != null)      // if adding in middle 
                {
                    latest.setHead(current.getHead());    // point head at previous
                    current.getHead().setTail(latest);
                }
                else
                {
                    first = latest;
                }

                // Can never be at the end
                latest.setTail(current);              //point tail at current
                current.setHead(latest);              // point current head at last
                             
            }

            current = latest;                         // last now becomes current
        }

        public bool isEnd()
        {
            if (current == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void gotoStart()
        {
            current = first;
        }

        public Data getCurrentData()
        {
            return current.getData();
        }

        public void gotoNext()
        {
            current = current.getTail();
        }

        public void gotoPrevious() 
        {
            current = current.getHead();
        }

    }
}
