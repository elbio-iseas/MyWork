﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Links
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
            Links links = new Links();
            links.addLink(new Data("One"));
            links.addLink(new Data("Two"));
            links.addLink(new Data("Three"));
            links.addLink(new Data("Four"));
            links.addLink(new Data("Five"));
  
            // loop through list
            links.gotoStart();
            while (!links.isEnd())
            {
                Console.WriteLine(links.getCurrentData().getName());
                links.gotoNext();
            }

            Console.ReadLine();
            */

            LinksDouble links = new LinksDouble();
          /*  links.addBeforeCurrent(new Data("One"));
            links.addBeforeCurrent(new Data("Two"));
            links.addBeforeCurrent(new Data("Three"));
            links.addBeforeCurrent(new Data("Four"));
            links.addBeforeCurrent(new Data("Five"));
            links.addBeforeCurrent(new Data("Six"));
           */

            links.addAfterCurrent(new Data("One"));
            links.addAfterCurrent(new Data("Two"));
            links.addAfterCurrent(new Data("Three"));
            links.addAfterCurrent(new Data("Four"));
            links.addAfterCurrent(new Data("Five"));
            links.addAfterCurrent(new Data("Six"));


        }
    }
}
