﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Links
{
    class Links
    {

        Link head;
        Link current;
        Link last;

        public Links()
        {
            head = null;
            current = null;
            last = null;
        }

        public void addLink(Data data)
        {

            last = new Link(new Data(data.getName()), null);
            if (head == null)
            {
                head = last;
                current = last;
            }
            else
            {
                current.setLink(last);
                current = last;
            }
        }

        public void addLinkAtCurrent(Data data)
        {
            last = current;
            current = new Link(new Data(data.getName()), null);
            // Not possible because current doesn't know what the link before it is

        }

        public bool isEnd()
        {
            if (current == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void gotoStart()
        {
            current = head;
        }

        public Data getCurrentData()
        {
            return current.getData();
        }

        public void gotoNext()
        {
            current = current.getLink();
        }
    }
}
