﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Links
{
    class LinkD
    {
        LinkD linkHead;
        Data data;
        LinkD linkTail;

        public LinkD(LinkD linkHead, Data data, LinkD linkTail)
        {
            this.linkHead = linkHead;
            this.data = data;
            this.linkTail = linkTail;
        }

        public Data getData() 
        { 
            return this.data; 
        }

        public LinkD getHead() {
            return this.linkHead;
        }

        public LinkD getTail()
        {
            return this.linkTail;
        }
        
        public void setHead(LinkD linkHead) {
            this.linkHead = linkHead;
        }

        public void setTail(LinkD linkTail)
        {
            this.linkTail = linkTail;
        }
    }
}
