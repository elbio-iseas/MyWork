﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Links
{
    class Link
    {
        Data data;
        Link link;

        public Link(Data data, Link link)
        {
            this.data = data;
            this.link = link;
        }

        public Data getData() 
        { 
            return this.data; 
        }

        public Link getLink() {
            return this.link;
        }
        
        public void setLink(Link link) {
            this.link = link;
        }
    }
}
