﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Links
{
    class Node
    {
        Node parent;
        Node left;
        Data data;
        Node right;

        public Node(Node parent, Node left, Data data, Node right)
        {
            this.parent = parent;
            this.left = left;
            this.data = data;
            this.right = right;
        }

        public Data getData()
        {
            return this.data;
        }

        public Node getParent()
        {
            return this.parent;
        }

        public Node getLeft()
        {
            return this.left;
        }

        public Node getRight()
        {
            return this.right;
        }

        public void setParent(Node parent)
        {
            this.parent = parent;
        }

        public void setLeft(Node left)
        {
            this.left = left;
        }

        public void setRight(Node right)
        {
            this.right = right;
        }
    }
}
