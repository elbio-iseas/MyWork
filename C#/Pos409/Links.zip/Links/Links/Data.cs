﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Links
{
    class Data
    {
        string name;

        public Data(string name)
        {
            this.name = name;
        }

        public Data(Data data)
        {
            this.name = data.name;
        }

        public string getName() 
        {
            return this.name;
        }

        public string ToString()
        {
            return name;
        }
    }
}
