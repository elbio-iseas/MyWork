﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace usingNunit
{
    [TestFixture]
    class PersonTest
    {

        Person person;
        public PersonTest()
        {
            
        }

        [SetUp]
        public void Init()
        {
            person = new Person("John", "Abraham", 10);
        }

        [Test]
        public void isNameJohnSmith()
        {
            Assert.IsFalse("John Smith" == person.fullName);
        }

        [Test]
        public void isAgeEqual()
        {
            Assert.AreEqual(10, person.Age);
        }

        [Test]
        public void isNameJohnAbraham()
        {
            Assert.AreEqual("John Abraham", person.fullName);
        }

        [Test]
        public void balanceBeforeCarPurchase()
        {
            Assert.AreEqual(100000, person.CashBalance);
        }

        [Test]
        public void balanceAfterCarPurchase()
        {
            person.buyCar(30000);
            Assert.AreEqual(80000, person.CashBalance);
        }

    }
}
