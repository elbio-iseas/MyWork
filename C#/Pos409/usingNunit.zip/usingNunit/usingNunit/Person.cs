﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace usingNunit
{
    class Person
    {
        string firstName;
        string lastName;
        int age;
        float cashBalance;

       // #region Constructors
        Person()
        {
            firstName = "";
            lastName = "";
            age = 0;
            cashBalance = 0;
        }

        public Person(string firstName, string lastName, int age)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
            cashBalance = 100000;
        }
       // #endregion

       // #region Properties
        public int Age
        {
            get { return this.age; }
        }

        public string fullName
        {
            get { return firstName + " " + lastName; }
        }
        
        public float CashBalance
        {
            get { return this.cashBalance; }
        }
      //  #endregion

      //  #region Methods
        public void buyCar(float cost)
        {
            cashBalance -= cost;
        }
      //  #endregion
    }
}
